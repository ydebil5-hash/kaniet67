void main() {
  for (int i = 10; i >= 1; i--) {
    print(i);
  }
  print('Старт!');
}